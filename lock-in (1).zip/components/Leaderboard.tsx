
import React from 'react';
import { UserState } from '../types';
import { MOCK_LEADERBOARD, getRank } from '../constants';

interface LeaderboardProps {
  user: UserState;
}

const Leaderboard: React.FC<LeaderboardProps> = ({ user }) => {
  const userRank = getRank(user.level);
  const displayName = user.username.split('@')[0].toUpperCase();

  return (
    <div className="flex flex-col min-h-screen bg-black text-white p-6 max-w-md mx-auto relative pb-24">
      <div className="pt-8 pb-10">
        <h1 className="text-[10px] text-zinc-600 font-black tracking-[0.5em] uppercase mb-1">Global Standing</h1>
        <h2 className="text-4xl font-black italic tracking-tighter uppercase drop-shadow-[0_0_15px_rgba(255,255,255,0.2)]">Leaderboard</h2>
      </div>

      <div className="space-y-4">
        {MOCK_LEADERBOARD.map((player, idx) => (
          <div 
            key={player.username}
            className={`flex items-center p-4 bg-zinc-950 border rounded-xl ${idx < 3 ? 'border-white/20' : 'border-zinc-900'}`}
          >
            <span className={`w-8 font-mono text-xs font-black ${idx === 0 ? 'text-yellow-500' : idx === 1 ? 'text-zinc-400' : idx === 2 ? 'text-orange-700' : 'text-zinc-600'}`}>
              #{idx + 1}
            </span>
            <div className="flex-1">
              <h3 className="text-sm font-black tracking-tight uppercase">{player.username}</h3>
              <p className="text-[9px] text-zinc-500 font-bold tracking-widest uppercase">{player.rank}</p>
            </div>
            <div className="text-right">
              <span className="text-xs font-mono font-black">L{player.level}</span>
              <p className="text-[8px] text-zinc-600 font-bold uppercase">{player.sessions} SESSIONS</p>
            </div>
          </div>
        ))}

        {/* User's Entry */}
        <div className="sticky bottom-0 mt-8 flex items-center p-5 bg-white text-black rounded-2xl shadow-2xl z-10 transform scale-105">
           <span className="w-8 font-black text-xs">YOU</span>
           <div className="flex-1">
              <h3 className="text-sm font-black tracking-tight uppercase">{displayName}</h3>
              <p className="text-[9px] text-zinc-600 font-black tracking-widest uppercase">{userRank}</p>
           </div>
           <div className="text-right">
              <span className="text-xs font-mono font-black">L{user.level}</span>
              <p className="text-[8px] text-zinc-700 font-bold uppercase">{user.completedSessions} SESSIONS</p>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Leaderboard;
