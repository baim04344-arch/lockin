
import React, { useState, useRef } from 'react';
import { UserState, Mission } from '../types';
import { MOTIVATIONAL_QUOTES, getRank } from '../constants';
import MissionAction from './MissionAction';

interface DashboardProps {
  user: UserState;
  onCompleteMission: (id: string) => void;
  onSkipMission: (id: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ user, onCompleteMission, onSkipMission }) => {
  const [selectedMission, setSelectedMission] = useState<Mission | null>(null);
  const clickSound = useRef(new Audio('https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3'));
  
  const playClick = () => {
    clickSound.current.currentTime = 0;
    clickSound.current.play().catch(() => {});
  };

  const quote = MOTIVATIONAL_QUOTES[Math.floor(Date.now() / 86400000) % MOTIVATIONAL_QUOTES.length];
  const rank = getRank(user.level);

  const displayName = user.username.split('@')[0].toUpperCase();

  return (
    <div className="flex flex-col min-h-screen bg-black text-white p-6 max-w-md mx-auto relative pb-24 overflow-y-auto">
      {selectedMission && (
        <MissionAction 
          mission={selectedMission} 
          onComplete={onCompleteMission} 
          onSkip={() => onSkipMission(selectedMission.id)}
          onClose={() => setSelectedMission(null)} 
        />
      )}

      <div className="absolute top-0 left-0 w-full h-1/2 bg-gradient-to-b from-zinc-900/20 to-transparent pointer-events-none"></div>

      <div className="flex justify-between items-center pt-8 pb-10 relative z-10">
        <div className="space-y-1">
          <h1 className="text-[9px] text-zinc-600 font-black tracking-[0.4em] uppercase">Operator Active</h1>
          <h2 className="text-3xl font-black italic tracking-tighter drop-shadow-sm">{displayName}</h2>
        </div>
        <div className="text-right space-y-1">
          <h1 className="text-[9px] text-zinc-600 font-black tracking-[0.4em] uppercase">Current Tier</h1>
          <div className="flex flex-col items-end">
            <span className="text-xl font-black text-white italic tracking-tighter shadow-white/20 drop-shadow-[0_0_8px_rgba(255,255,255,0.4)]">{rank}</span>
            <span className="text-[10px] font-mono font-bold text-zinc-500">LVL {user.level}</span>
          </div>
        </div>
      </div>

      <div className="mb-14 relative z-10 p-5 bg-zinc-950 border border-zinc-900 rounded-2xl shadow-2xl">
        <div className="flex justify-between items-end mb-3">
          <div className="flex flex-col">
            <span className="text-[9px] font-black tracking-widest text-zinc-500 uppercase">Synchronization</span>
            <span className="text-[10px] font-bold text-zinc-400">NEXT: {getRank(user.level + 1)}</span>
          </div>
          <span className="text-[12px] font-mono font-black text-white">{user.xp % 100}%</span>
        </div>
        <div className="h-1.5 bg-zinc-900 rounded-full overflow-hidden">
          <div 
            className="h-full bg-white transition-all duration-1000 shadow-[0_0_15px_rgba(255,255,255,0.8)]"
            style={{ width: `${user.xp % 100}%` }}
          />
        </div>
      </div>

      <div className="mb-12 flex-1 relative z-10">
        <div className="flex items-center justify-between mb-8 px-1">
          <h3 className="text-[11px] font-black tracking-[0.3em] uppercase text-zinc-500">Live Objectives</h3>
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 bg-white rounded-full animate-ping"></span>
            <span className="text-[9px] font-bold text-zinc-600 uppercase tracking-widest">Auto-Refill On</span>
          </div>
        </div>
        
        <div className="space-y-5">
          {user.dailyMissions.map((mission: Mission) => (
            <div 
              key={mission.id}
              onClick={() => {
                if (!mission.completed) {
                  playClick();
                  setSelectedMission(mission);
                }
              }}
              className={`group relative flex flex-col p-5 bg-zinc-950 border transition-all cursor-pointer rounded-2xl ${mission.completed ? 'border-zinc-900 opacity-30 scale-[0.97]' : 'border-zinc-800 hover:border-zinc-500 hover:bg-zinc-900/40 active:scale-95 shadow-xl'}`}
            >
              <div className="flex items-center mb-2 justify-between">
                 <div className="flex items-center">
                    <div className={`w-2 h-2 rounded-full mr-3 ${mission.completed ? 'bg-zinc-700' : 'bg-white shadow-[0_0_8px_white]'}`}></div>
                    <span className="text-[10px] font-black tracking-[0.2em] text-zinc-500 uppercase">
                      {mission.type || 'PROTOCOL'}
                    </span>
                 </div>
                 {!mission.completed && (
                   <span className="text-[10px] font-mono font-bold text-zinc-400">+{mission.xp}XP</span>
                 )}
              </div>
              
              <div className="flex items-center justify-between gap-4">
                <span className={`text-base font-bold tracking-tight leading-snug ${mission.completed ? 'text-zinc-600 line-through' : 'text-zinc-100'}`}>
                  {mission.text}
                </span>
                {mission.completed && (
                  <div className="bg-white/10 p-1.5 rounded-full">
                    <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20"><path d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"/></svg>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
        <p className="mt-8 text-[9px] text-zinc-700 text-center font-bold tracking-[0.3em] uppercase opacity-50">Objectives refill upon completion.</p>
      </div>

      <div className="px-6 py-8 border-t border-zinc-900">
        <p className="text-zinc-500 text-[11px] font-medium italic leading-relaxed text-center tracking-wide max-w-[80%] mx-auto opacity-60">
          "{quote}"
        </p>
      </div>
    </div>
  );
};

export default Dashboard;
