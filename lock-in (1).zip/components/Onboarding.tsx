
import React, { useState } from 'react';
import { LifePath } from '../types';
import { PATH_METADATA } from '../constants';

interface OnboardingProps {
  isLoggedIn: boolean;
  onLogin: (email: string) => void;
  onSelectPath: (path: LifePath) => void;
}

const Onboarding: React.FC<OnboardingProps> = ({ isLoggedIn, onLogin, onSelectPath }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoginMode, setIsLoginMode] = useState(false);
  const [error, setError] = useState('');

  const validateAndSubmit = () => {
    setError('');
    if (!email || !email.includes('@')) {
      setError('ENTER A VALID EMAIL');
      return;
    }
    if (password.length < 6) {
      setError('PASSWORD TOO WEAK (MIN 6 CHARS)');
      return;
    }
    onLogin(email);
  };

  if (!isLoggedIn) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-8 bg-black relative overflow-hidden">
        {/* Subtle grid background */}
        <div className="absolute inset-0 opacity-10 pointer-events-none" 
             style={{ backgroundImage: 'linear-gradient(#222 1px, transparent 1px), linear-gradient(90deg, #222 1px, transparent 1px)', backgroundSize: '40px 40px' }}>
        </div>

        <div className="w-full max-w-sm space-y-12 relative z-10">
          <div className="text-center">
            <h1 className="text-7xl font-black tracking-tighter mb-2 italic drop-shadow-[0_0_15px_rgba(255,255,255,0.3)]">LOCK IN</h1>
            <p className="text-gray-500 text-[10px] font-bold tracking-[0.4em] uppercase">Forging The Next Generation</p>
          </div>
          
          <div className="space-y-4">
            <div className="flex border border-zinc-900 bg-zinc-950 rounded p-1 mb-4">
              <button 
                onClick={() => { setIsLoginMode(false); setError(''); }}
                className={`flex-1 py-3 text-[10px] font-bold tracking-widest transition-all rounded-sm ${!isLoginMode ? 'bg-white text-black shadow-lg shadow-white/10' : 'text-zinc-600 hover:text-zinc-300'}`}
              >
                SIGN UP
              </button>
              <button 
                onClick={() => { setIsLoginMode(true); setError(''); }}
                className={`flex-1 py-3 text-[10px] font-bold tracking-widest transition-all rounded-sm ${isLoginMode ? 'bg-white text-black shadow-lg shadow-white/10' : 'text-zinc-600 hover:text-zinc-300'}`}
              >
                LOGIN
              </button>
            </div>

            <div className="space-y-3">
              <div className="relative">
                <input 
                  type="email" 
                  placeholder="EMAIL ADDRESS"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-900 p-4 text-sm focus:outline-none focus:border-white focus:bg-zinc-900 transition-all tracking-widest rounded-md"
                />
              </div>
              <div className="relative">
                <input 
                  type="password" 
                  placeholder="PASSWORD"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-900 p-4 text-sm focus:outline-none focus:border-white focus:bg-zinc-900 transition-all tracking-widest rounded-md"
                />
              </div>
              {error && <p className="text-[9px] text-red-500 font-black tracking-widest text-center mt-2 animate-pulse uppercase">{error}</p>}
            </div>

            <button 
              onClick={validateAndSubmit}
              className="w-full bg-white text-black py-5 text-xs font-black tracking-[0.3em] hover:bg-zinc-200 transition-all active:scale-95 rounded-sm shadow-xl shadow-white/5"
            >
              {isLoginMode ? 'AUTHORIZE ACCESS' : 'CREATE PROTOCOL'}
            </button>
          </div>
          
          <div className="flex flex-col items-center gap-4">
             <p className="text-zinc-700 text-[9px] text-center uppercase tracking-[0.2em] leading-loose">
               Secure encrypted connection established.
             </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen p-8 bg-black overflow-y-auto">
      <div className="flex-1 flex flex-col justify-center max-w-lg mx-auto w-full space-y-12 my-12">
        <div className="space-y-2">
          <h2 className="text-4xl font-black tracking-tighter uppercase">Why are you doing this?</h2>
          <p className="text-zinc-500 text-xs tracking-widest uppercase font-bold">Select your growth path</p>
        </div>

        <div className="grid gap-4 pb-12">
          {Object.entries(PATH_METADATA).map(([key, value]) => (
            <button
              key={key}
              onClick={() => onSelectPath(key as LifePath)}
              className="group flex flex-col items-start p-6 bg-zinc-950 border border-zinc-900 hover:border-white transition-all text-left relative overflow-hidden active:scale-95 rounded-xl shadow-lg"
            >
              <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-20 transition-opacity">
                <span className="text-6xl font-black">{key[0]}</span>
              </div>
              <span className="text-lg font-black tracking-tight uppercase group-hover:text-white transition-colors">{value.title}</span>
              <span className="text-[10px] text-zinc-500 mt-1 font-bold tracking-widest uppercase">{value.description}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Onboarding;
