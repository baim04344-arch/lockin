
import React, { useState, useEffect, useRef } from 'react';

interface FocusModeProps {
  onComplete: () => void;
  onCancel: () => void;
}

const FocusMode: React.FC<FocusModeProps> = ({ onComplete, onCancel }) => {
  const [timeLeft, setTimeLeft] = useState(30 * 60); // 30 minutes in seconds
  const [isActive, setIsActive] = useState(true);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    let interval: number | undefined;
    if (isActive && timeLeft > 0) {
      interval = window.setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      onComplete();
    }
    return () => clearInterval(interval);
  }, [isActive, timeLeft, onComplete]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const quitSession = () => {
    if (window.confirm("ARE YOU GIVING UP? This will count as a failure.")) {
      onCancel();
    }
  };

  return (
    <div className="fixed inset-0 bg-black z-50 flex flex-col items-center justify-center text-white p-8">
      {/* Background Pulse */}
      <div className="absolute inset-0 bg-white/5 animate-pulse-slow"></div>
      
      <div className="relative z-10 w-full max-w-sm flex flex-col items-center">
        <div className="mb-2">
          <span className="text-zinc-600 text-[10px] font-bold tracking-[0.5em] uppercase">Status: Locked In</span>
        </div>
        
        <div className="mb-12">
          <h1 className="text-8xl font-black mono tracking-tighter locked-glow">
            {formatTime(timeLeft)}
          </h1>
        </div>

        <div className="w-full h-1 bg-zinc-900 rounded-full mb-12 relative overflow-hidden">
          <div 
            className="absolute top-0 left-0 h-full bg-white transition-all duration-1000 ease-linear"
            style={{ width: `${(timeLeft / (30 * 60)) * 100}%` }}
          />
        </div>

        <div className="text-center space-y-6 max-w-xs">
          <p className="text-zinc-400 text-sm italic tracking-wide">
            "The distance between your dreams and reality is called discipline."
          </p>
          
          <div className="pt-12">
            <button 
              onClick={quitSession}
              className="text-zinc-700 hover:text-white transition-colors text-[10px] font-bold tracking-[0.3em] uppercase border-b border-transparent hover:border-white pb-1"
            >
              Terminate Session
            </button>
          </div>
        </div>
      </div>

      {/* Ambient sound control (visual only for this prototype) */}
      <div className="absolute bottom-12 flex gap-4">
        <div className="w-1 h-8 bg-zinc-800 rounded-full flex items-end">
          <div className="w-full bg-white/40 h-1/2 rounded-full"></div>
        </div>
        <div className="w-1 h-8 bg-zinc-800 rounded-full flex items-end">
          <div className="w-full bg-white/40 h-1/4 rounded-full"></div>
        </div>
        <div className="w-1 h-8 bg-zinc-800 rounded-full flex items-end">
          <div className="w-full bg-white/40 h-3/4 rounded-full"></div>
        </div>
        <div className="w-1 h-8 bg-zinc-800 rounded-full flex items-end">
          <div className="w-full bg-white/40 h-2/3 rounded-full"></div>
        </div>
      </div>
    </div>
  );
};

export default FocusMode;
