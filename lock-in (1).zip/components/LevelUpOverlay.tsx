
import React, { useEffect, useRef } from 'react';

interface LevelUpOverlayProps {
  level: number;
  rank: string;
  isRankUp: boolean;
  onClose: () => void;
}

const LevelUpOverlay: React.FC<LevelUpOverlayProps> = ({ level, rank, isRankUp, onClose }) => {
  const soundRef = useRef(new Audio('https://assets.mixkit.co/active_storage/sfx/1435/1435-preview.mp3'));

  useEffect(() => {
    soundRef.current.play().catch(() => {});
  }, []);

  return (
    <div className="fixed inset-0 z-[200] bg-black flex flex-col items-center justify-center p-8 text-white overflow-hidden">
      <div className="absolute inset-0 bg-white/5 animate-pulse pointer-events-none"></div>
      
      {/* Visual background blast */}
      <div className="absolute w-[500px] h-[500px] bg-white/10 rounded-full blur-[120px] animate-pulse"></div>

      <div className="relative z-10 text-center space-y-8 max-w-sm">
        <div className="space-y-2">
          <span className="text-zinc-500 text-[10px] font-black tracking-[0.5em] uppercase">Status Update</span>
          <h2 className="text-6xl font-black italic tracking-tighter uppercase drop-shadow-[0_0_20px_white]">
            {isRankUp ? 'RANK ACHIEVED' : 'LEVEL UP'}
          </h2>
        </div>

        <div className="space-y-1">
          <p className="text-[12px] font-bold text-zinc-400 tracking-[0.2em] uppercase">You are now</p>
          <p className="text-4xl font-black italic tracking-tighter text-white drop-shadow-sm">{rank}</p>
          <p className="text-sm font-mono font-bold text-zinc-500 uppercase">LEVEL {level}</p>
        </div>

        <div className="pt-12">
          <button 
            onClick={onClose}
            className="w-full bg-white text-black py-5 rounded-2xl font-black tracking-[0.6em] uppercase text-xs shadow-[0_0_40px_rgba(255,255,255,0.4)] active:scale-95 transition-all"
          >
            ACKNOWLEDGE
          </button>
        </div>
      </div>
    </div>
  );
};

export default LevelUpOverlay;
