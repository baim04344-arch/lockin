
import React, { useState, useEffect, useRef } from 'react';
import { Mission } from '../types';

interface MissionActionProps {
  mission: Mission;
  onComplete: (id: string) => void;
  onSkip: () => void;
  onClose: () => void;
}

const MissionAction: React.FC<MissionActionProps> = ({ mission, onComplete, onSkip, onClose }) => {
  const [timeLeft, setTimeLeft] = useState<number | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [timerFinished, setTimerFinished] = useState(false);
  
  // Audio references
  const clickSound = useRef(new Audio('https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3'));
  const tickSound = useRef(new Audio('https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3'));
  const completeSound = useRef(new Audio('https://assets.mixkit.co/active_storage/sfx/2020/2020-preview.mp3'));
  const alertSound = useRef(new Audio('https://assets.mixkit.co/active_storage/sfx/951/951-preview.mp3'));

  const playClick = () => {
    clickSound.current.currentTime = 0;
    clickSound.current.play().catch(() => {});
  };

  const playTick = () => {
    tickSound.current.currentTime = 0;
    tickSound.current.play().catch(() => {});
  };

  // Parse mission text for duration
  useEffect(() => {
    const text = mission.text.toLowerCase();
    const minuteMatch = text.match(/(\d+)\s*(minute|min|mins)/);
    const hourMatch = text.match(/(\d+)\s*(hour|hr|hrs)/);
    
    let seconds = 0;
    if (minuteMatch) {
      seconds = parseInt(minuteMatch[1]) * 60;
    } else if (hourMatch) {
      seconds = parseInt(hourMatch[1]) * 3600;
    }

    if (seconds > 0) {
      setTimeLeft(seconds);
      setTimerFinished(false);
    } else {
      setTimerFinished(true); // Non-timed tasks are ready by default
    }
  }, [mission.text]);

  useEffect(() => {
    let interval: number | undefined;
    if (isRunning && timeLeft !== null && timeLeft > 0) {
      interval = window.setInterval(() => {
        playTick();
        setTimeLeft(prev => {
          if (prev !== null && prev <= 1) {
            setTimerFinished(true);
            alertSound.current.play().catch(() => {});
            return 0;
          }
          return prev !== null ? prev - 1 : null;
        });
      }, 1000);
    } else if (timeLeft === 0) {
      setIsRunning(false);
    }
    return () => clearInterval(interval);
  }, [isRunning, timeLeft]);

  const formatTime = (totalSeconds: number) => {
    const h = Math.floor(totalSeconds / 3600);
    const m = Math.floor((totalSeconds % 3600) / 60);
    const s = totalSeconds % 60;
    if (h > 0) return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleComplete = () => {
    playClick();
    completeSound.current.play().catch(() => {});
    onComplete(mission.id);
    onClose();
  };

  const handleSkip = () => {
    playClick();
    onSkip();
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black z-[100] flex flex-col items-center justify-center p-8 text-white overflow-hidden">
      <div className="absolute inset-0 bg-zinc-900/20 animate-pulse-slow pointer-events-none"></div>

      <button 
        onClick={() => { playClick(); onClose(); }}
        className="absolute top-12 left-8 text-zinc-600 hover:text-white transition-colors flex items-center gap-2 group"
      >
        <svg className="w-5 h-5 group-hover:-translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M15 19l-7-7 7-7"/></svg>
        <span className="text-[10px] font-black tracking-[0.2em] uppercase">BACK</span>
      </button>

      <div className="relative z-10 w-full max-w-sm flex flex-col items-center text-center space-y-12">
        <div className="space-y-4">
          <span className="text-zinc-500 text-[10px] font-black tracking-[0.5em] uppercase">Current Objective</span>
          <h2 className="text-4xl font-black italic tracking-tighter uppercase leading-tight drop-shadow-2xl">
            {mission.text}
          </h2>
        </div>

        {timeLeft !== null && (
          <div className="space-y-6">
            <div className={`text-7xl font-black mono tracking-tighter transition-all ${timerFinished ? 'text-green-500 drop-shadow-[0_0_15px_rgba(34,197,94,0.5)]' : 'locked-glow'}`}>
              {formatTime(timeLeft)}
            </div>
            {!isRunning && !timerFinished && (
              <button 
                onClick={() => { playClick(); setIsRunning(true); }}
                className="bg-white text-black px-10 py-4 rounded-full text-[10px] font-black tracking-[0.3em] uppercase active:scale-95 transition-all shadow-xl"
              >
                START TIMER
              </button>
            )}
            {isRunning && (
              <button 
                onClick={() => { playClick(); setIsRunning(false); }}
                className="border border-zinc-800 text-zinc-400 px-10 py-4 rounded-full text-[10px] font-black tracking-[0.3em] uppercase active:scale-95 transition-all"
              >
                PAUSE
              </button>
            )}
            {timerFinished && timeLeft === 0 && (
              <div className="text-[10px] font-black tracking-widest text-green-500 uppercase animate-bounce">
                Objective Ready
              </div>
            )}
          </div>
        )}

        <div className="pt-8 w-full space-y-4">
          {timerFinished ? (
            <button 
              onClick={handleComplete}
              className="w-full bg-white text-black py-6 rounded-2xl font-black tracking-[0.4em] uppercase text-sm shadow-[0_0_40px_rgba(255,255,255,0.2)] active:scale-95 transition-all transform hover:scale-[1.02]"
            >
              CONFIRM COMPLETION
            </button>
          ) : (
            <div className="w-full py-6 rounded-2xl border border-zinc-900 text-zinc-700 font-black tracking-[0.4em] uppercase text-sm cursor-not-allowed">
              COMPLETE TIMER FIRST
            </div>
          )}
          
          <button 
            onClick={handleSkip}
            className="w-full bg-zinc-950 border border-zinc-900 text-zinc-500 py-4 rounded-2xl font-black tracking-[0.3em] uppercase text-[10px] hover:border-zinc-700 hover:text-zinc-300 active:scale-95 transition-all"
          >
            I CAN'T DO IT (SWAP TASK)
          </button>
          
          <p className="text-[9px] text-zinc-800 font-bold tracking-[0.2em] uppercase leading-loose">
            Skipping resets this objective slot without penalty.
          </p>
        </div>
      </div>
    </div>
  );
};

export default MissionAction;
